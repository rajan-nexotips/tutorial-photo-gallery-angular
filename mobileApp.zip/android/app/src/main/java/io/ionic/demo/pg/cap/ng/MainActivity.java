package io.ionic.demo.pg.cap.ng;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
